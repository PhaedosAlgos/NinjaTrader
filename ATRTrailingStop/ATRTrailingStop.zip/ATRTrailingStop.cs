#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ATRTrailingStop[] cacheATRTrailingStop;

		
		public ATRTrailingStop ATRTrailingStop(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return ATRTrailingStop(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public ATRTrailingStop ATRTrailingStop(ISeries<double> input, int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			if (cacheATRTrailingStop != null)
				for (int idx = 0; idx < cacheATRTrailingStop.Length; idx++)
					if (cacheATRTrailingStop[idx].FastATRPeriod == fastATRPeriod && cacheATRTrailingStop[idx].FastATRMultiplier == fastATRMultiplier && cacheATRTrailingStop[idx].SlowATRPeriod == slowATRPeriod && cacheATRTrailingStop[idx].SlowATRMultiplier == slowATRMultiplier && cacheATRTrailingStop[idx].SlowTrailTF == slowTrailTF && cacheATRTrailingStop[idx].FastTrailTF == fastTrailTF && cacheATRTrailingStop[idx].EqualsInput(input))
						return cacheATRTrailingStop[idx];
			return CacheIndicator<ATRTrailingStop>(new ATRTrailingStop(){ FastATRPeriod = fastATRPeriod, FastATRMultiplier = fastATRMultiplier, SlowATRPeriod = slowATRPeriod, SlowATRMultiplier = slowATRMultiplier, SlowTrailTF = slowTrailTF, FastTrailTF = fastTrailTF }, input, ref cacheATRTrailingStop);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ATRTrailingStop ATRTrailingStop(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrailingStop(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public Indicators.ATRTrailingStop ATRTrailingStop(ISeries<double> input , int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrailingStop(input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ATRTrailingStop ATRTrailingStop(int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrailingStop(Input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}


		
		public Indicators.ATRTrailingStop ATRTrailingStop(ISeries<double> input , int fastATRPeriod, double fastATRMultiplier, int slowATRPeriod, double slowATRMultiplier, bool slowTrailTF, bool fastTrailTF)
		{
			return indicator.ATRTrailingStop(input, fastATRPeriod, fastATRMultiplier, slowATRPeriod, slowATRMultiplier, slowTrailTF, fastTrailTF);
		}

	}
}

#endregion
