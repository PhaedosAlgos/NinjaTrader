#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TimeframeContinuity[] cacheTimeframeContinuity;

		
		public TimeframeContinuity TimeframeContinuity(bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			return TimeframeContinuity(Input, outlineCandlesTF, fillCandlesTF, hTF1, hTF2, hTF3, hTF4);
		}


		
		public TimeframeContinuity TimeframeContinuity(ISeries<double> input, bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			if (cacheTimeframeContinuity != null)
				for (int idx = 0; idx < cacheTimeframeContinuity.Length; idx++)
					if (cacheTimeframeContinuity[idx].OutlineCandlesTF == outlineCandlesTF && cacheTimeframeContinuity[idx].FillCandlesTF == fillCandlesTF && cacheTimeframeContinuity[idx].HTF1 == hTF1 && cacheTimeframeContinuity[idx].HTF2 == hTF2 && cacheTimeframeContinuity[idx].HTF3 == hTF3 && cacheTimeframeContinuity[idx].HTF4 == hTF4 && cacheTimeframeContinuity[idx].EqualsInput(input))
						return cacheTimeframeContinuity[idx];
			return CacheIndicator<TimeframeContinuity>(new TimeframeContinuity(){ OutlineCandlesTF = outlineCandlesTF, FillCandlesTF = fillCandlesTF, HTF1 = hTF1, HTF2 = hTF2, HTF3 = hTF3, HTF4 = hTF4 }, input, ref cacheTimeframeContinuity);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TimeframeContinuity TimeframeContinuity(bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			return indicator.TimeframeContinuity(Input, outlineCandlesTF, fillCandlesTF, hTF1, hTF2, hTF3, hTF4);
		}


		
		public Indicators.TimeframeContinuity TimeframeContinuity(ISeries<double> input , bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			return indicator.TimeframeContinuity(input, outlineCandlesTF, fillCandlesTF, hTF1, hTF2, hTF3, hTF4);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TimeframeContinuity TimeframeContinuity(bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			return indicator.TimeframeContinuity(Input, outlineCandlesTF, fillCandlesTF, hTF1, hTF2, hTF3, hTF4);
		}


		
		public Indicators.TimeframeContinuity TimeframeContinuity(ISeries<double> input , bool outlineCandlesTF, bool fillCandlesTF, int hTF1, int hTF2, int hTF3, int hTF4)
		{
			return indicator.TimeframeContinuity(input, outlineCandlesTF, fillCandlesTF, hTF1, hTF2, hTF3, hTF4);
		}

	}
}

#endregion
