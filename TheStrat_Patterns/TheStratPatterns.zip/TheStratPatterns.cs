#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TheStratPatterns[] cacheTheStratPatterns;

		
		public TheStratPatterns TheStratPatterns(bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			return TheStratPatterns(Input, displayPatternsTF, outlineCandlesTF, fillCandlesTF, offset);
		}


		
		public TheStratPatterns TheStratPatterns(ISeries<double> input, bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			if (cacheTheStratPatterns != null)
				for (int idx = 0; idx < cacheTheStratPatterns.Length; idx++)
					if (cacheTheStratPatterns[idx].DisplayPatternsTF == displayPatternsTF && cacheTheStratPatterns[idx].OutlineCandlesTF == outlineCandlesTF && cacheTheStratPatterns[idx].FillCandlesTF == fillCandlesTF && cacheTheStratPatterns[idx].Offset == offset && cacheTheStratPatterns[idx].EqualsInput(input))
						return cacheTheStratPatterns[idx];
			return CacheIndicator<TheStratPatterns>(new TheStratPatterns(){ DisplayPatternsTF = displayPatternsTF, OutlineCandlesTF = outlineCandlesTF, FillCandlesTF = fillCandlesTF, Offset = offset }, input, ref cacheTheStratPatterns);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TheStratPatterns TheStratPatterns(bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			return indicator.TheStratPatterns(Input, displayPatternsTF, outlineCandlesTF, fillCandlesTF, offset);
		}


		
		public Indicators.TheStratPatterns TheStratPatterns(ISeries<double> input , bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			return indicator.TheStratPatterns(input, displayPatternsTF, outlineCandlesTF, fillCandlesTF, offset);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TheStratPatterns TheStratPatterns(bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			return indicator.TheStratPatterns(Input, displayPatternsTF, outlineCandlesTF, fillCandlesTF, offset);
		}


		
		public Indicators.TheStratPatterns TheStratPatterns(ISeries<double> input , bool displayPatternsTF, bool outlineCandlesTF, bool fillCandlesTF, int offset)
		{
			return indicator.TheStratPatterns(input, displayPatternsTF, outlineCandlesTF, fillCandlesTF, offset);
		}

	}
}

#endregion
